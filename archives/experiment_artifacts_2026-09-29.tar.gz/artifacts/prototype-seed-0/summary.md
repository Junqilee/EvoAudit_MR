| Patch | Hidden full audit | Direct | Fixed heldout | Fixed random | EvoAudit-MR | EvoAudit-MR reason |
| --- | --- | --- | --- | --- | --- | --- |
| semantic_adapter | reliable | commit | commit | commit | commit | none |
| positional_adapter | unreliable | commit | commit | commit | reject | target_mr_failed |
| alias_only_adapter | unreliable | commit | commit | commit | reject | replay_regression |
| restricted_lookup_adapter | unreliable | commit | commit | commit | reject | safety_invariant_failed |
