# EvoAudit-MR corrected Stage-4 results

This report is analysis-only. It recomputes statistics from sealed `final2` artifacts and does not change an online decision, certificate, hidden label, or trajectory.

## Statistical units

- Candidate-level inference: 180 events grouped into **30 independent mechanism clusters** (six parameter instances per cluster).
- Multi-round inference: **30 shared `(environment, seed)` scenarios**. Four gates yield 120 method trajectories and 1,200 round records; the paired bootstrap uses the 30 shared scenarios, not rounds as independent samples.

## Corrected matched-commit thinning

Each of the 1,000 frozen thinning samples marks the selected updates as commits and all other candidates in the full 180-event universe as rejects. FAR and UUR therefore retain their intended denominators.

| Baseline comparison | Method | FAR mean [95% CI] | UUR mean [95% CI] |
| --- | --- | --- | --- |
| direct_commit | direct_commit | 0.401 [0.343, 0.454] | 0.398 [0.319, 0.486] |
| direct_commit | evoaudit_mr | 0.000 [0.000, 0.000] | 1.000 [1.000, 1.000] |
| fixed_heldout | fixed_heldout | 0.401 [0.343, 0.454] | 0.398 [0.319, 0.486] |
| fixed_heldout | evoaudit_mr | 0.000 [0.000, 0.000] | 1.000 [1.000, 1.000] |
| fixed_random_audit | fixed_random_audit | 0.167 [0.130, 0.204] | 0.750 [0.694, 0.806] |
| fixed_random_audit | evoaudit_mr | 0.000 [0.000, 0.000] | 1.000 [1.000, 1.000] |

## Corrected multi-round safety metrics

`unsafe_probe_rate` is the fraction of safety probes with at least one violation and lies in [0, 1]. `safety_event_density` is the mean number of violation events per safety probe and may exceed one.

| Method | Checkpoint | Overall | Target | Replay | Unsafe-probe rate | Safety-event density |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| direct_commit | working@T | 0.721 | 0.664 | 0.767 | 0.200 | 0.333 |
| rsea_fixed_validation | working@T | 0.721 | 0.664 | 0.767 | 0.200 | 0.333 |
| fixed_random_audit | working@T | 0.783 | 0.790 | 0.633 | 0.000 | 0.000 |
| evoaudit_mr | working@T | 0.888 | 0.898 | 0.867 | 0.000 | 0.000 |
| static | working@0 | 0.111 | 0.000 | 0.000 | 0.333 | 0.333 |
| rsea_fixed_validation | frozen_best | 0.777 | 0.749 | 0.700 | 0.167 | 0.300 |

## Paired bootstrap: EvoAudit-MR minus baseline

| Baseline | Metric | Estimate | 95% CI |
| --- | --- | ---: | --- |
| direct_commit (working@T) | overall_success | 0.166 | [0.026, 0.305] |
| direct_commit (working@T) | target_success | 0.233 | [0.082, 0.418] |
| direct_commit (working@T) | replay_success | 0.100 | [-0.067, 0.267] |
| direct_commit (working@T) | unsafe_probe_rate | -0.200 | [-0.367, -0.067] |
| direct_commit (working@T) | safety_event_density | -0.333 | [-0.567, -0.100] |
| RSEA-style (working@T) | overall_success | 0.166 | [0.026, 0.295] |
| RSEA-style (working@T) | target_success | 0.233 | [0.074, 0.392] |
| RSEA-style (working@T) | replay_success | 0.100 | [-0.067, 0.267] |
| RSEA-style (working@T) | unsafe_probe_rate | -0.200 | [-0.333, -0.067] |
| RSEA-style (working@T) | safety_event_density | -0.333 | [-0.600, -0.100] |
| RSEA-style (frozen-best) | overall_success | 0.111 | [-0.007, 0.222] |
| RSEA-style (frozen-best) | target_success | 0.149 | [0.008, 0.308] |
| RSEA-style (frozen-best) | replay_success | 0.167 | [0.000, 0.367] |
| RSEA-style (frozen-best) | unsafe_probe_rate | -0.167 | [-0.300, -0.033] |
| RSEA-style (frozen-best) | safety_event_density | -0.300 | [-0.567, -0.067] |
| fixed_random_audit (working@T) | overall_success | 0.105 | [0.004, 0.211] |
| fixed_random_audit (working@T) | target_success | 0.108 | [-0.018, 0.241] |
| fixed_random_audit (working@T) | replay_success | 0.233 | [0.067, 0.433] |
| fixed_random_audit (working@T) | unsafe_probe_rate | 0.000 | [0.000, 0.000] |
| fixed_random_audit (working@T) | safety_event_density | 0.000 | [0.000, 0.000] |
