# EvoAudit-MR formal experiment report

## Primary candidate-level result (sealed online run; offline hidden evaluation)

| Method | TP | FP | TN | FN | FAR | FDR | UUR | SVR | Audit pairs | Tool calls |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| direct_commit | 72 | 108 | 0 | 0 | 1.000 | 0.600 | 1.000 | 0.267 | 0.000 | 0.000 |
| fixed_heldout | 72 | 108 | 0 | 0 | 1.000 | 0.600 | 1.000 | 0.267 | 6.000 | 19.200 |
| fixed_random_audit | 72 | 24 | 84 | 0 | 0.222 | 0.250 | 1.000 | 0.000 | 6.000 | 17.533 |
| evoaudit_mr | 72 | 0 | 108 | 0 | 0.000 | 0.000 | 1.000 | 0.000 | 6.000 | 17.533 |

The sealed main protocol uses six parent-candidate probe pairs. Cluster-bootstrap CIs are retained in `cluster_bootstrap.csv` in the formal artifact directory.

## Primary multi-round result (30 trajectories; shared 90-task hidden final exam)

| Method | Checkpoint | Overall | Target | Replay | Safety violation |
| --- | --- | ---: | ---: | ---: | ---: |
| direct_commit | working@T | 0.721 | 0.664 | 0.767 | 0.333 |
| rsea_fixed_validation | frozen_best | 0.777 | 0.749 | 0.700 | 0.300 |
| rsea_fixed_validation | working@T | 0.721 | 0.664 | 0.767 | 0.333 |
| fixed_random_audit | working@T | 0.783 | 0.790 | 0.633 | 0.000 |
| evoaudit_mr | working@T | 0.888 | 0.898 | 0.867 | 0.000 |
| static | working@0 | 0.111 | 0.000 | 0.000 | 0.333 |

## Paired multi-round bootstrap: EvoAudit-MR minus baseline

| Baseline | Metric | Estimate | 95% CI |
| --- | --- | ---: | --- |
| direct_commit (working@T) | overall_success | 0.166 | [0.026, 0.305] |
| direct_commit (working@T) | target_success | 0.233 | [0.082, 0.418] |
| direct_commit (working@T) | replay_success | 0.100 | [-0.067, 0.267] |
| direct_commit (working@T) | safety_violation_rate | -0.333 | [-0.600, -0.100] |
| RSEA-style (working@T) | overall_success | 0.166 | [0.038, 0.295] |
| RSEA-style (working@T) | target_success | 0.233 | [0.074, 0.400] |
| RSEA-style (working@T) | replay_success | 0.100 | [-0.067, 0.300] |
| RSEA-style (working@T) | safety_violation_rate | -0.333 | [-0.600, -0.100] |
| RSEA-style (frozen-best) | overall_success | 0.111 | [-0.006, 0.217] |
| RSEA-style (frozen-best) | target_success | 0.149 | [0.006, 0.308] |
| RSEA-style (frozen-best) | replay_success | 0.167 | [-0.033, 0.367] |
| RSEA-style (frozen-best) | safety_violation_rate | -0.300 | [-0.600, -0.067] |
| fixed_random_audit (working@T) | overall_success | 0.105 | [0.004, 0.211] |
| fixed_random_audit (working@T) | target_success | 0.108 | [-0.018, 0.241] |
| fixed_random_audit (working@T) | replay_success | 0.233 | [0.067, 0.400] |
| fixed_random_audit (working@T) | safety_violation_rate | 0.000 | [0.000, 0.000] |

## Appendix diagnostics (post-reveal, separate from primary sealed decisions)

### Candidate-level budget scan

| Budget | Method | FAR | UUR | Tool calls |
| --- | --- | ---: | ---: | ---: |
| B=3 | rsea_fixed_validation | 1.000 | 1.000 | 9.600 |
| B=3 | fixed_random_audit | 0.111 | 1.000 | 8.800 |
| B=3 | evoaudit_mr | 0.056 | 1.000 | 8.800 |
| B=6 | rsea_fixed_validation | 1.000 | 1.000 | 19.200 |
| B=6 | fixed_random_audit | 0.222 | 1.000 | 17.533 |
| B=6 | evoaudit_mr | 0.000 | 1.000 | 17.533 |
| B=12 | rsea_fixed_validation | 1.000 | 1.000 | 38.400 |
| B=12 | fixed_random_audit | 0.222 | 1.000 | 35.067 |
| B=12 | evoaudit_mr | 0.000 | 1.000 | 35.067 |

### Candidate-level component ablation (six pairs)

| Variant | FAR | UUR | SVR |
| --- | ---: | ---: | ---: |
| evoaudit_mr | 0.000 | 1.000 | 0.000 |
| no_target_mr | 0.222 | 1.000 | 0.000 |
| no_replay_mr | 0.278 | 1.000 | 0.000 |
| no_safety_gate | 0.333 | 1.000 | 0.333 |
| no_scope_routing | 0.667 | 1.000 | 0.083 |

### Five-seed multi-round component ablation

| Variant | Overall | Replay | Safety violation | False commits |
| --- | ---: | ---: | ---: | ---: |
| evoaudit_mr | 0.944 | 0.933 | 0.000 | 0.000 |
| no_target_mr | 0.744 | 0.600 | 0.000 | 0.133 |
| no_replay_mr | 0.944 | 0.933 | 0.000 | 0.000 |
| no_safety_gate | 0.956 | 1.000 | 0.600 | 0.333 |
| no_scope_routing | 0.767 | 0.600 | 0.000 | 0.133 |

The five-seed multi-round no-replay control is a null result in this curriculum: the target-MR strict-improvement requirement rejects the same replay-regressive proposals before the replay check changes the decision. This is reported as a boundary of the current sequence design, not converted into a positive component claim.

All appendix tables are analysis-only and leave the primary online logs, certificates, phase locks, and hidden labels unchanged.
