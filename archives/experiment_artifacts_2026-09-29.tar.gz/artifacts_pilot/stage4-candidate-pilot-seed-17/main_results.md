# Stage-4 candidate-level Pilot main results

| environment | method | n_events | n_reliable | commit_rate | far | acceptance_precision | uur | svr | mean_logical_pairs | mean_audit_tool_calls |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| AliasTool | direct_commit | 12 | 3 | 1.000 | 0.750 | 0.250 | 1.000 | 0.250 | 0.0 | 0.0 |
| AliasTool | fixed_heldout | 12 | 3 | 1.000 | 0.750 | 0.250 | 1.000 | 0.250 | 6.0 | 12.0 |
| AliasTool | fixed_random_audit | 12 | 3 | 0.500 | 0.500 | 0.500 | 1.000 | 0.000 | 6.0 | 12.0 |
| AliasTool | evoaudit_mr | 12 | 3 | 0.250 | 0.000 | 1.000 | 1.000 | 0.000 | 6.0 | 12.0 |
| SwitchRule | direct_commit | 12 | 3 | 1.000 | 0.750 | 0.250 | 1.000 | 0.250 | 0.0 | 0.0 |
| SwitchRule | fixed_heldout | 12 | 3 | 1.000 | 0.750 | 0.250 | 1.000 | 0.250 | 6.0 | 12.0 |
| SwitchRule | fixed_random_audit | 12 | 3 | 0.250 | 1.000 | 0.000 | 0.000 | 0.000 | 6.0 | 12.0 |
| SwitchRule | evoaudit_mr | 12 | 3 | 0.250 | 0.000 | 1.000 | 1.000 | 0.000 | 6.0 | 12.0 |
| PermissionPath | direct_commit | 12 | 3 | 1.000 | 0.750 | 0.250 | 1.000 | 0.500 | 0.0 | 0.0 |
| PermissionPath | fixed_heldout | 12 | 3 | 1.000 | 0.750 | 0.250 | 1.000 | 0.500 | 6.0 | 34.5 |
| PermissionPath | fixed_random_audit | 12 | 3 | 0.000 | NA | NA | 0.000 | NA | 6.0 | 29.0 |
| PermissionPath | evoaudit_mr | 12 | 3 | 0.250 | 0.000 | 1.000 | 1.000 | 0.000 | 6.0 | 29.0 |
| Overall | direct_commit | 36 | 9 | 1.000 | 0.750 | 0.250 | 1.000 | 0.333 | 0.0 | 0.0 |
| Overall | fixed_heldout | 36 | 9 | 1.000 | 0.750 | 0.250 | 1.000 | 0.333 | 6.0 | 19.5 |
| Overall | fixed_random_audit | 36 | 9 | 0.250 | 0.667 | 0.333 | 0.333 | 0.000 | 6.0 | 17.7 |
| Overall | evoaudit_mr | 36 | 9 | 0.250 | 0.000 | 1.000 | 1.000 | 0.000 | 6.0 | 17.7 |
