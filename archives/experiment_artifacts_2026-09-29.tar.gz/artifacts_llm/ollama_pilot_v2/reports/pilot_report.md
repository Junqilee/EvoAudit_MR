# Ollama LLM Proposal Pilot v2 report

This is a development Pilot for constrained LLM-proposed updates. It reports descriptive, not significance, evidence.

## Generator

```json
{
  "behavior_signature_unique": 2,
  "behavioral_noop": 1,
  "compiled_intent_unique": 2,
  "executable": 10,
  "invalid": 1,
  "metric_scope": "generator_unconditional_30_slots",
  "raw_proposal_unique": 30,
  "total_slots": 30,
  "unexecutable": 19
}
```

## Candidate-diversity criteria

```json
{
  "both_environments_executable": true,
  "canonical_reliable_at_least_3": true,
  "canonical_unreliable_at_least_3": false,
  "executable_at_least_18": false
}
```

## Conditional candidate metrics

| Method | FAR | FDR | UUR | Reliable commits / 30 slots | Unreliable commits / 30 slots |
| --- | ---: | ---: | ---: | ---: | ---: |
| direct_commit | 0.0 | 0.0 | 1.0 | 9 | 0 |
| rsea_fixed_validation | 0.0 | 0.0 | 1.0 | 9 | 0 |
| fixed_random_audit | 0.0 | 0.0 | 0.8888888888888888 | 8 | 0 |
| evoaudit_mr | 0.0 | 0.0 | 1.0 | 9 | 0 |

## Persistent-evolution final summary

| Environment | Method | n trajectories | Target | Replay | Unsafe probe rate | Overall |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| AliasTool | direct_commit | 3 | 1.0 | 1.0 | 0.0 | 1.0 |
| AliasTool | rsea_fixed_validation | 3 | 1.0 | 1.0 | 0.0 | 1.0 |
| AliasTool | fixed_random_audit | 3 | 1.0 | 1.0 | 0.0 | 1.0 |
| AliasTool | evoaudit_mr | 3 | 1.0 | 1.0 | 0.0 | 1.0 |
| AliasTool | static | 3 | 0.0 | 0.0 | 0.0 | 0.0 |
| PermissionPath | direct_commit | 3 | 0.3333333333333333 | 0.3333333333333333 | 0.0 | 0.5555555555555555 |
| PermissionPath | rsea_fixed_validation | 3 | 0.3333333333333333 | 0.3333333333333333 | 0.0 | 0.5555555555555555 |
| PermissionPath | fixed_random_audit | 3 | 0.0 | 0.0 | 0.0 | 0.3333333333333333 |
| PermissionPath | evoaudit_mr | 3 | 0.3333333333333333 | 0.3333333333333333 | 0.0 | 0.5555555555555555 |
| PermissionPath | static | 3 | 0.0 | 0.0 | 0.0 | 0.3333333333333333 |
| Overall | direct_commit | 6 | 0.6666666666666666 | 0.6666666666666666 | 0.0 | 0.7777777777777778 |
| Overall | rsea_fixed_validation | 6 | 0.6666666666666666 | 0.6666666666666666 | 0.0 | 0.7777777777777778 |
| Overall | fixed_random_audit | 6 | 0.5 | 0.5 | 0.0 | 0.6666666666666666 |
| Overall | evoaudit_mr | 6 | 0.6666666666666666 | 0.6666666666666666 | 0.0 | 0.7777777777777778 |
| Overall | static | 6 | 0.0 | 0.0 | 0.0 | 0.16666666666666666 |

## Interpretation boundary

The compiler maps a restricted public DSL into a finite policy family. Therefore this Pilot can support only the claim that EvoAudit-MR audits constrained LLM-proposed updates; it does not demonstrate arbitrary free-form prompt, tool, memory, or workflow modification.
