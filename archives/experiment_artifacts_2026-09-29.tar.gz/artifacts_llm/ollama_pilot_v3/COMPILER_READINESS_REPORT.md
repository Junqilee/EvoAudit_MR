# V3 Compiler Readiness Report

Gate A uses V2 online-public data only; it contains no hidden label, task, seed, or gate decision.

```json
{
  "annotation_ambiguous_reject_cases": 28,
  "annotation_supported_cases": 2,
  "behavior_cases": 23,
  "explicitly_rejected_policy_combinations": 12,
  "router_cases": 23,
  "valid_assignment_cases": 23,
  "valid_policy_combinations": 132
}
```
