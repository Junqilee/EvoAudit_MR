# V3b Compiler Readiness Report

Gate A1 uses V2 online-public data only.

```json
{
  "annotation_ambiguous_reject_cases": 28,
  "annotation_supported_cases": 2,
  "behavior_cases": 23,
  "explicitly_rejected_policy_combinations": 12,
  "router_cases": 23,
  "valid_assignment_cases": 23,
  "valid_policy_combinations": 132
}
```
